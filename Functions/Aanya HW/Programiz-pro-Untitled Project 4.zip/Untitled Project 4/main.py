
def myfunc(a):
    if True:
        print("Hello")
    if False:
        print("Goodbye")
